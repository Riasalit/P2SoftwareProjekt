﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using HAPI;
using System.Diagnostics;
using System.IO;
using BattleshipWeb;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace BattleshipTest.ControlTest
{
    [TestClass]
    public class GameRunning
    {
        //Can Game run
        [TestMethod]
        public void CanGameRun()
        {
        }
    }
}
